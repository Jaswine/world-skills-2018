#pragma once
#include <Arduino.h>

extern const String prettySeconds(unsigned long time_s);
extern const String prettyMillis(unsigned long time_ms);