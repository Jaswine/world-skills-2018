#pragma once
#include "Global.h"
#include "utils/TimeUtils.h"

void SerialPrint(String errorLevel, String module, String msg);